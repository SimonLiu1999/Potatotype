from client.client import Client


client = Client()
client.start()
