from server.server import Server


server = Server()
server.start()
