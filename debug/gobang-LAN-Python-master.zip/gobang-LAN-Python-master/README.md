# gobang-LAN-Python
局域网五子棋实现联机对战（Python）
